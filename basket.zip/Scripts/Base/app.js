
import config from 'Scripts/config.js';
import authInterceptorService from 'Scripts/Base/authInterceptorService.js';
//import authService from 'Scripts/Base/authService.js';
import {default as controllers} from 'Scripts/app.controllers.js';
import {default as services} from 'Scripts/app.services.js';
import {default as directives} from 'Scripts/app.directives.js';
//import {default as filters} from 'Scripts/app.filters.js';


var moduleName='app'; 

angular.module(moduleName,['ionic', 'LocalStorageModule', 'ngResource', 'ngCordova','ionic-datepicker','SignalR',  controllers, services, directives])
    .factory('authInterceptorService', authInterceptorService)
    //.factory('authService', authService)
    .config(config)
    .config(function ($httpProvider, $ionicConfigProvider) {
         $ionicConfigProvider.backButton.previousTitleText(false);//.text('&emsp;&emsp;');
        //$httpProvider.defaults.cache=true;
        $httpProvider.interceptors.push('authInterceptorService');
    })
    .constant('appBase', {
        baseUrl: 'http://localhost/authJwtApp/',        
        apiUrl: 'http://aquonyx-001-site16.smarterasp.net/',
        clientId: 'jwtApp'//nativeApp//jwtApp
    })
    .factory('signalRSvc', ['$rootScope', 'Hub', '$timeout', 'localStorageService', 'appBase',  function (rootScope, Hub, $timeout, localStorageService, appBase) {
    var jwtSvc = this;
    //Hub setup
    var hub = new Hub('chat', {
        //rootPath:'http://localhost:49375/signalr',
         rootPath: appBase.apiUrl+'signalr',
        listeners: {
            'newConnection': function (name) {
                rootScope.$broadcast("newConnection", name);
            },
            'removeConnection': function (name) {
                rootScope.$broadcast("removeConnection", name);
            },
            'receiveMessage': function (data) {
                rootScope.$broadcast("receiveMessage", data);
            },
            'onlineUsers': function (data) {
                rootScope.$broadcast("onlineUsers", data);
            },
        },
        methods: ['sendMessage','initHub'],
        errorHandler: function (error) {
            console.log(error);
        },
        hubDisconnected: function () {
            if (hub.connection.lastError) {
                $timeout(function () { hub.connect(); }, 5000);
            }
        },
        start:{jsonp:true}
        //start:{jsonp:true, transport: 'webSockets'}
        
        //,logging: true

    });
    var authData = localStorageService.get('authorizationData');
    
    if (authData) {	    
        //$.signalR.ajaxDefaults.headers = { Authorization: "Bearer " + authData.token };
        jwtSvc.userName = authData.userName||'unknowen';
        //console.log(jwtSvc.userName);
    } else {
        jwtSvc.userName = 'unknowen';
    }
    jwtSvc.connectionDone=hub.promise;
   
    jwtSvc.sendMessage = function (sendto, message) {
        try { hub.sendMessage(jwtSvc.userName, sendto, message); } catch (error) { }
    };
    jwtSvc.initHub = function () {
        try { hub.initHub(jwtSvc.userName); } catch (error) { }
    }
    jwtSvc.receiveMessage=function(callback){
         rootScope.$on("receiveMessage", callback);
    }
    jwtSvc.newConnection=function(callback){
         rootScope.$on("newConnection", callback);
    }
    return jwtSvc;
}])
.run(function($ionicPlatform, localStorageService, $cordovaToast){
     $ionicPlatform.ready(function() {
        var user= localStorageService.get('authorizationData');
        localStorageService.clearAll();
        localStorageService.set('authorizationData', user);
         return;
        var pushNotification =window.plugins.pushNotification;
        
        window.onNotification = function(e){
          switch(e.event){
            case 'registered':
              if(e.regid.length > 0){
                localStorageService.set('device_token', {value:e.regid});
                navigator.notification.beep(1);
                //$cordovaToast.showLongCenter(e.regid);
              }
            break;
    
            case 'message':
              navigator.notification.beep(2);
              $cordovaToast.showLongCenter(e.payload.title+' : '+e.payload.message);
            break;
    
            case 'error':
              alert('error occured');
            break;
    
          }
        };
    
        window.errorHandler = function(error){
          alert('an error occured');
        }
        pushNotification.register(
          onNotification,
          errorHandler,
          {
            'badge': 'true',
            'sound': 'true',
            'alert': 'true',
            'senderID': '566748745797',
            'ecb': 'onNotification'
          }
        );
     });
     
});
    //.run(['authService', function(authService, $rootScope, $templateCache) {
        //authService.fillAuthData();
        //$rootScope.$on('$viewContentLoaded', function() {
           // $templateCache.removeAll();
        //});
   // }]);

export default moduleName;

