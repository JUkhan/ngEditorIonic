
class BaseSvc
{
    constructor(http){
        this.http=http;      
    }
    POST(url, data){
        return this.request({url:url, method:'POST', data:data});
    }
    GET(url){
         return this.request({url:url, method:'GET'});
    }
    request(config){
        return this.http(config);
    }
    request2(config){
        var id=config.url+angular.toJson(config.data||{});
        if(this.dataCache && this.q){
            var  defer=this.q.defer();
            if(this.dataCache.get(id)){
                defer.resolve(this.dataCache.get(id));
            }else{
                this.http(config).success(res=>{
                    this.dataCache.put(id, res);
                    defer.resolve(res);
                });
            }
	        return defer.promise;
        }else{
            return this.http(config);
        }
    }
    getDummyData(obj){ 
      
           return this.postRequest('Jwt/GetDummyData',obj);  
           //return this.request({url:'Jwt/GetDummyData', method:'POST', data:obj}); 
    }
    getTableData(spName, spParams){
        
        if(!angular.isArray(spParams)){
            spParams=this.getParams(spParams);
        }
         return  this.http.post('Repository/GetTableData',{spName:spName, spParams:spParams}); 
    }
    getScalarValue(spName, spParams){
        
         if(!angular.isArray(spParams)){
            spParams=this.getParams(spParams);
         }
         return  this.http.post('Repository/GetScalarValue',{spName:spName, spParams:spParams}); 
    }
    exportExcel(spName, spParams, fileName){
        
         if(!angular.isArray(spParams)){
            spParams=  angular.toJson(this.getParams(spParams));
         }
       window.location='Repository/ExportExcel/?spName='+spName+'&spParams='+spParams+'&fileName='+fileName;
    }
    getParams(obj){
        var paramList=[];
        for(var key in obj){
            paramList.push({name:key, value:obj[key]});
        }
        return paramList;
    }
    
}
export default BaseSvc;