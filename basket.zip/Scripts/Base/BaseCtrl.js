
class BaseCtrl{      
    constructor(scope){ 
        //this.ionicSideMenuDelegate=ionicSideMenuDelegate;
        this.initDone=false;
        scope.$on('FilterValueChanged', function(event, obj){this.filterValueChanged(obj);}.bind(this));
        setTimeout(function() {this.initDone=true;}.bind(this), 0);
        
        if(typeof(String.prototype.format)=== "undefined"){
            String.prototype.format= function () {
                 var str = this;
                 for (var i = 0; i < arguments.length; i++) {
                     str = str.replace(new RegExp('\\{' + i + '\\}', 'g'), arguments[i]);
                 }
                 return str;
            }
        }
        Date.prototype.toString=function(){
            return '{0}-{1}-{2}'.format(this.getFullYear(), this.getMonth()+1, this.getDate());
        }
    }
    
    filterValueChanged(obj){
     
    } 
    getIcon(m){
        
        var colors={NotVisited:'Red', Visited:'Blue', SellOurProduct:'Green'};
        return  'img/{0}-{1}.png'.format(m.clientMarker.clienType,colors[m.clientMarker.markerType]);
       
	}
    openMenu(){
	     this.ionicSideMenuDelegate.toggleLeft();
	}
	toastAlert(message){
	    if(!navigator.notification){
	        alert(message);
	        return;
	    }
	    this.toast.showLongCenter(message);
	}
	alert(title, msg){
	    if(!navigator.notification){
	        alert(msg);
	        return;
	    }
	   
	    navigator.notification.alert( msg,  function () { }, title,  'OK'  );
	}
	confirm(title, msg, onConfirm){
	   if(!navigator.notification){
	       if(confirm(msg)){
	           onConfirm();
	       }
	        return;
	    }
      navigator.notification.confirm(
              msg,  
              onConfirm,              
              title,            
              'Confirm'          
          );
    }
    playBeep() {
        navigator.notification.beep(3);
    }
    vibrate() {
        navigator.notification.vibrate(2000);
    }
	routeMap(latlngList, map, delay=1000){
         var len=latlngList.length, i=0, xarr=[];
            if(len<=0) return;
           map.panTo(new google.maps.LatLng(latlngList[0].lat, latlngList[0].lng));
          do{
             if(i>0)i--;
             var temp=[];
             temp.push(latlngList[i]);
             i++;
             if(i<len){
                   temp.push(latlngList[i]);
             }
             else
               temp.push(latlngList[i-1]);
               xarr.push(temp);
              i++;
          }while(i<len);
        var colors=['#FF0000','#00FF00', '#0000FF','#FF00FF','#FFFF00','#00FFFF','#FF00FF']; 
        function getColor(){ return colors[Math.floor((Math.random()*7)+1)];}
        function renderPolyline(arr, index){
	       
    	    var flightPath = new google.maps.Polyline({
                path: arr[index],
                geodesic: true,
                strokeColor: getColor(),
                strokeOpacity: 1.0,
                strokeWeight: 5
              });
    
            flightPath.setMap(map);
            index++;
    	    if(index<arr.length){
    	       
    	        setTimeout(function() {
    	            map.panTo(new google.maps.LatLng(arr[index][0].lat, arr[index][0].lng));
    	            renderPolyline(arr, index); }, delay);
    	    }else{
    	        map.panTo(new google.maps.LatLng(arr[index-1][1].lat, arr[index-1][1].lng));
    	    }
       }
       renderPolyline(xarr, 0);
	}
	distance(lon1, lat1, lon2, lat2){
	    
	     if (typeof(Number.prototype.toRad) === "undefined") {
          Number.prototype.toRad = function() {
            return this * Math.PI / 180;
          }
        }
          var R = 6371; // Radius of the earth in km
          var dLat = (lat2-lat1).toRad();  // Javascript functions in radians
          var dLon = (lon2-lon1).toRad(); 
          var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1.toRad()) * Math.cos(lat2.toRad()) * 
                  Math.sin(dLon/2) * Math.sin(dLon/2); 
          var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
          var d = R * c; // Distance in km
          
          return d*1000;
	}
    initFilter() {
        var scope=this;
        if (window.sessionStorage["jwtFilter"]) {
            var ob = angular.fromJson(window.sessionStorage["jwtFilter"]);
            if (angular.isObject(ob)) {
                for (var prop in ob) {					
                    //if (scope.hasOwnProperty(prop)) {
                        scope[prop] = ob[prop];
                    //}
                }
            }
        }
       
    }
    syncCall(g){
        let it=g(),ret;
        (function iterate(val){
            ret=it.next(val);
            if(!ret.done){             
                if(ret.value){
                    if('success' in ret.value){
                        ret.value.success(iterate);
                    }
                    else if('then' in ret.value){
                        ret.value.then(iterate);
                    }
                    else{
                        iterate(ret.value);
                    }
                }
            }
        })();
    }
    arrayRemove(list, callback){
        var fx = function (arr) { return arr.length; };
        for (var i = 0; i < fx(list) ; i++) {
            if (callback(list[i])) { list.splice(i, 1); i--; }
        }
        return list;
    }
    getParams(obj){
        var paramList=[];
        for(var key in obj){
            paramList.push({name:key, value:obj[key]});
        }
        return paramList;
    }
}
export default BaseCtrl;
