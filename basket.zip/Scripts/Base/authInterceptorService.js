
 function authInterceptorService($q, $injector, $state, localStorageService) {

    var authInterceptorServiceFactory = {};

    var _request = function (config) {

        config.headers = config.headers || {};
       
        var authData = localStorageService.get('authorizationData');
        if (authData) {
            //config.headers.Authorization = 'Bearer ' + authData.token;
        }
        
        $injector.get('$ionicLoading').show({
            content: 'loading...',
            showBackdrop: false
        });
        return config;
    }

    var _responseError = function (rejection) {
        $injector.get('$ionicLoading').hide();
        if (rejection.status === 401) {
           localStorageService.set('authorizationData', null);
           $state.go('loginNav');
        }
        return $q.reject(rejection);
    }
    
    var _response= function(response) {
       
            $injector.get('$ionicLoading').hide();
            return response;
        }
    authInterceptorServiceFactory.response=_response;
    authInterceptorServiceFactory.request = _request;
    authInterceptorServiceFactory.responseError = _responseError;

    return authInterceptorServiceFactory;
 }

 authInterceptorService.$inject=['$q', '$injector','$location', 'localStorageService'];
export default authInterceptorService;