import BaseSvc from 'Scripts/Base/BaseSvc.js';

class homeSvc extends BaseSvc
{
	constructor(http){
		super(http);
		this.http= http;
	}
	static homeFactory(http)	{
		return new homeSvc(http);
	}
}
homeSvc.homeFactory.$inject=['$http'];
export default homeSvc.homeFactory;