import BaseCtrl from 'Scripts/Base/BaseCtrl.js';

class homeCtrl extends BaseCtrl
{
	constructor(scope, svc){
		super(scope);
		this.svc = svc;
		this.title='home';
	}
}
homeCtrl.$inject=['$scope', 'homeSvc'];
export default homeCtrl;