import BaseCtrl from 'Scripts/Base/BaseCtrl.js';

class homeCtrl extends BaseCtrl
{
	constructor(scope, svc){
		super(scope);
		this.svc = svc;
		this.title='home-ionic';
	}
}
homeCtrl.$inject=['$scope', 'homeSvc'];
export default homeCtrl;