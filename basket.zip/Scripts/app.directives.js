

var moduleName='app.Directives';

angular.module(moduleName, [])
;

export default moduleName;